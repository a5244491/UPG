package com.yinhai.bcs.upg.message.common;

/**
 * 消息
 * @author Administrator
 * @version 1.0
 * @updated 15-4-2014 17:20:45
 */
public class UPGMsgBody {
	
}
