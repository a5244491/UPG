package com.yinhai.bcs.upg.dbservice;

//import com.yinhai.bcs.sdb.client.SDBClient;

public class SDBClientFactory {
	//public static SDBClient sdbClient ;
}
