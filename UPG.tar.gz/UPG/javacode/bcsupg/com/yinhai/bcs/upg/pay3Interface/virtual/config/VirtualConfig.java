package com.yinhai.bcs.upg.pay3Interface.virtual.config;

public class VirtualConfig {
	public static final String VIRTUAL_INTERFACE_SDB = "http://192.168.10.122:8708/sdb/core/serviceAction.do";
}
