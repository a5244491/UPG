package com.yinhai.bcs.upg.message.trade;

import java.util.Map;

import com.yinhai.bcs.upg.message.common.RspUPGMessage;


public class WithdrawRspUPGMsg extends RspUPGMessage{


	public Map<String, Object> toMap() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
