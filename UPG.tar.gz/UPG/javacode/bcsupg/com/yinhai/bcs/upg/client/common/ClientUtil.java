package com.yinhai.bcs.upg.client.common;

public class ClientUtil {

}
